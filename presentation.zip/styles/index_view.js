try{
  pdf2htmlEX.defaultViewer = new pdf2htmlEX.Viewer({});
  }catch(e){}